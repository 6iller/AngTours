import { Component } from '@angular/core';

@Component({
  selector: 'app-statistic',
  imports: [],
  templateUrl: './statistic.component.html',
  styleUrl: './statistic.component.scss',
})
export class StatisticComponent { }
